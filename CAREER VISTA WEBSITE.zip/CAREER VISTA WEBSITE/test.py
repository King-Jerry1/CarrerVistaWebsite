for i in range(-1, 1):
    print(i)

z = 10
y = 0
x = x = z > y or z==y
if x :
    print (x)

my_list = [3,1,-1]

my_list [-1] = my_list[-2]

if my_list:
    print(my_list)


my_list=[0,1,2,3]
x = 1

for elem in my_list:
    x = elem * x
    print(x)

