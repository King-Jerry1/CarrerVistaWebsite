var navLinks = document.getElementById("navLinks");
const element = document.querySelector('.fa .fa-times');
const style = getComputedStyle(element);
var allList =  document.querySelector(".nav-links-sm ul li")
function showMenu(){
    navLinks.style.top= "-5px"; 
    navLinks.style.position= "fixed"; 
    navLinks.style.height= "200vh"; 
    navLinks.style.right= "0"; 
    navLinks.style.width= "300px";
    navLinks.style.transition= "1.5s"; 
    navLinks.style.backgroundColor ="#000000";
    navLinks.style.display= "block"; 
    navLinks.style.padding= "20px 50px"; 
    navLinks.style.textDecoration="none";


    
}

function hideMenu(){
    navLinks.style.right = "-500px";
    navLinks.style.display= "none"; 
    
}
